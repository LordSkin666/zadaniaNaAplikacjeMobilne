package com.example.zad6;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText emailField;
    private EditText passwordField;
    private EditText repeatPasswordField;
    private TextView messageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        emailField = findViewById(R.id.email);
        passwordField = findViewById(R.id.password);
        repeatPasswordField = findViewById(R.id.repeat_password);
        messageView = findViewById(R.id.message);
        Button registerButton = findViewById(R.id.register_button);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailField.getText().toString();
                String password = passwordField.getText().toString();
                String repeatPassword = repeatPasswordField.getText().toString();

                if (!email.contains("@")) {
                    messageView.setText("Nieprawidłowy adres email");
                } else if (!password.equals(repeatPassword)) {
                    messageView.setText("Hasła się różnią");
                } else {
                    messageView.setText("Witaj " + email);
                }
            }
        });
    }
}