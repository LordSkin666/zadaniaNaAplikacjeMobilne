package com.example.zad4;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private int totalScore = 0;
    private int rollCount = 0;
    private int roundScore = 0;

    private TextView dice1, dice2, dice3, dice4, dice5;
    private TextView roundScoreText, totalScoreText, rollCountText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);


        // Inicjalizacja TextView i Button
        dice1 = findViewById(R.id.dice1);
        dice2 = findViewById(R.id.dice2);
        dice3 = findViewById(R.id.dice3);
        dice4 = findViewById(R.id.dice4);
        dice5 = findViewById(R.id.dice5);

        roundScoreText = findViewById(R.id.roundScore);
        totalScoreText = findViewById(R.id.totalScore);
        rollCountText = findViewById(R.id.rollCount);

        Button rollButton = findViewById(R.id.rollButton);
        Button resetButton = findViewById(R.id.resetButton);

        rollButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rollDice();
            }
        });

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetGame();
            }
        });
    }

    // Funkcja do rzucania kośćmi
    private void rollDice() {
        Random rand = new Random();
        int[] diceResults = new int[5];
        for (int i = 0; i < diceResults.length; i++) {
            diceResults[i] = rand.nextInt(6) + 1; // Rzuty od 1 do 6
        }

        displayDiceResults(diceResults);
        roundScore = calculateRoundScore(diceResults);
        updateScore(roundScore);
        updateRollCount();
    }

    // Funkcja do wyświetlania wyników kości
    private void displayDiceResults(int[] diceResults) {
        dice1.setText(String.valueOf(diceResults[0]));
        dice2.setText(String.valueOf(diceResults[1]));
        dice3.setText(String.valueOf(diceResults[2]));
        dice4.setText(String.valueOf(diceResults[3]));
        dice5.setText(String.valueOf(diceResults[4]));
    }

    // Funkcja do obliczania wyniku rzutu
    private int calculateRoundScore(int[] diceResults) {
        int score = 0;
        int[] count = new int[7]; // Tablica do liczenia wystąpień wartości (1-6)
        for (int result : diceResults) {
            count[result]++;
        }
        for (int i = 1; i <= 6; i++) {
            if (count[i] >= 2) {
                score += i * count[i];
            }
        }
        roundScoreText.setText("Wynik tego losowania: " + score);
        return score;
    }

    // Funkcja do aktualizacji wyniku gry
    private void updateScore(int newScore) {
        totalScore += newScore;
        totalScoreText.setText("Wynik gry: " + totalScore);
    }

    // Funkcja do aktualizacji liczby rzutów
    private void updateRollCount() {
        rollCount++;
        rollCountText.setText("Liczba rzutów: " + rollCount);
    }

    // Funkcja do resetowania gry
    private void resetGame() {
        totalScore = 0;
        rollCount = 0;
        roundScore = 0;
        totalScoreText.setText("Wynik gry: " + totalScore);
        roundScoreText.setText("Wynik tego losowania: 0");
        rollCountText.setText("Liczba rzutów: 0");
        dice1.setText("?");
        dice2.setText("?");
        dice3.setText("?");
        dice4.setText("?");
        dice5.setText("?");
    }
}