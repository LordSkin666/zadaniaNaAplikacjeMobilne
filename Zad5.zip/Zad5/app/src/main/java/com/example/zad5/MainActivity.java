package com.example.zad5;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private int likeCount = 0;
    private TextView likeCounter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        likeCounter = findViewById(R.id.like_counter);
        TextView menuLike = findViewById(R.id.menu_like);
        TextView menuDislike = findViewById(R.id.menu_dislike);
        TextView menuSave = findViewById(R.id.menu_save);

        menuLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                likeCount++;
                updateLikeCounter();
            }
        });

        menuDislike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (likeCount > 0) {
                    likeCount--;
                    updateLikeCounter();
                }
            }
        });

        menuSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obecnie brak dodatkowej funkcji
            }
        });
    }

    private void updateLikeCounter() {
        likeCounter.setText(likeCount + " polubień");
    }
}