package com.example.zad3;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;


import androidx.lifecycle.ViewModelProvider;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Deklaracja widoków
    private TextView counterTextView, optionTextView;
    private EditText userInputEditText;
    private CheckBox optionCheckBox;
    private Switch themeSwitch;
    private Button incrementButton;
    private StateViewModel stateViewModel;

    // Zmienne stanu
    private int counter = 0; // Licznik
    private boolean isDarkMode = false; // Domyślny motyw

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        stateViewModel = new ViewModelProvider(this).get(StateViewModel.class);

        // Powiązanie widoków z kodem
        counterTextView = findViewById(R.id.counterTextView);
        userInputEditText = findViewById(R.id.userInputEditText);
        optionCheckBox = findViewById(R.id.optionCheckBox);
        optionTextView = findViewById(R.id.optionTextView);
        themeSwitch = findViewById(R.id.themeSwitch);
        incrementButton = findViewById(R.id.incrementButton);

        // Przywracanie stanu po obrocie ekranu
        if (savedInstanceState != null) {
            counter = savedInstanceState.getInt("counter", 0);
            counterTextView.setText("Licznik: " + counter);

            userInputEditText.setText(savedInstanceState.getString("userInput", ""));
            optionCheckBox.setChecked(savedInstanceState.getBoolean("isChecked", false));
            themeSwitch.setChecked(savedInstanceState.getBoolean("isDarkMode", false));

            // Pokazanie lub ukrycie TextView w zależności od CheckBox
            optionTextView.setVisibility(optionCheckBox.isChecked() ? TextView.VISIBLE : TextView.GONE);
        }

        // Obsługa przycisku do zwiększania licznika
        incrementButton.setOnClickListener(v -> {
            counter++;
            counterTextView.setText("Licznik: " + counter);
        });

        // Obsługa CheckBox
        optionCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            optionTextView.setVisibility(isChecked ? TextView.VISIBLE : TextView.GONE);
        });

        // Obsługa Switch (zmiana motywu)
        themeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            isDarkMode = isChecked;
            // (Opcjonalnie) Tutaj można dodać logikę do przełączania motywu
        });
    }

    // Zapisywanie stanu aplikacji przed zniszczeniem aktywności
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("counter", counter);
        outState.putString("userInput", userInputEditText.getText().toString());
        outState.putBoolean("isChecked", optionCheckBox.isChecked());
        outState.putBoolean("isDarkMode", themeSwitch.isChecked());
    }
}
